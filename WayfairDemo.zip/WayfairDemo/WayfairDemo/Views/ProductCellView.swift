//
//  ProductCell.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import SwiftUI

struct ProductCellView: View {
    
    var product: ProductItems
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("\(product.name)")
                .foregroundColor(Color.primary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.title2)
                .fontWeight(.bold)
                .padding(EdgeInsets(top: 10, leading: 10, bottom: 0, trailing: 0))

            Text("\(product.tagline)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.caption)
                .foregroundColor(Color.secondary)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 0))

            StarRatingView(rating: Float(product.rating))
                .frame(width: 300, height: 20)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 10, trailing: 0))

            
        }
        .overlay(
            RoundedRectangle(cornerRadius: 2)
                   .stroke(lineWidth: 0.2)
           )
        .background(Color.white)
        .compositingGroup()
        .shadow(color: Color.secondary, radius: 10, x: 0, y: 0)
        .padding(10)
   
    }
}


struct ProductCellView_Previews: PreviewProvider {
    
    static let product = ProductItems(name: "Yellow Chair", tagline: "Great is you like yellow!", rating: 4.35, date: "1-15-2018")
    
    static var previews: some View {
        ProductCellView(product: product)
        ProductCellView(product: product)
            .preferredColorScheme(.dark)
    }
}


