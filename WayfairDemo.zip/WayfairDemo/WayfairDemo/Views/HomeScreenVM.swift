//
//  HomeScreenVM.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

class HomeScreenVM: ObservableObject {
    
    private let service: NetworkClient

    
    @Published private(set) var products = [ProductItems]()
    
    
    init(service: NetworkClient = NetworkService()) {
        self.service = service
    }
    

    @MainActor
    func callAPI() async {
        
        let endpoint = Endpoint(
            path: EndPointPaths.search,
            queryItems: []
        )
        
        do {
            let searchResults: [ProductItems] = try await service.loadData(from: endpoint)
            self.products = searchResults

        } catch {
            print(error)
        }
    }
    
}

