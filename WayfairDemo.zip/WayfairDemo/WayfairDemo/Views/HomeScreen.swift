//
//  HomeScreen.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import SwiftUI

struct HomeScreen: View {
    
    @StateObject private var viewModel = HomeScreenVM()

    var body: some View {
        ScrollView {
            VStack {
                ForEach(viewModel.products, id: \.id) { product in
                    ProductCellView(product: product)
                }
            }
            .task {
                await viewModel.callAPI()
            }
        }

    }
}

struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreen()
        HomeScreen()
            .preferredColorScheme(.dark)
    }
}
