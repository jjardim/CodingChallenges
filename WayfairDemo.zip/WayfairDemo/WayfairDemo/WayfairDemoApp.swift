//
//  WayfairDemoApp.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import SwiftUI

@main
struct WayfairDemoApp: App {
    var body: some Scene {
        WindowGroup {
            HomeScreen()
        }
    }
}
