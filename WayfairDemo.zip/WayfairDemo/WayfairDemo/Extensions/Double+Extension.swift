//
//  Double+Extension.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

extension Double{
    func roundToClosestHalf() -> Double {
        return (self*2).rounded() / 2
    }

    func ridZero() -> String {
            let value = String(format: "%g", self)
            return value
    }
    
}

