//
//  ClientErrors.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

enum ClientErrors: Error {
  case dataParsingFailed
}

