//
//  ServerErrors.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

enum ServerError: Error {
  case timeOut
  case notOK
}

