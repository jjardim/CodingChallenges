//
//  Endpoint.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

struct EndPointPaths {
  static let search = "interview-sandbox/android/json-to-list/products.v1.json"
}


struct Endpoint {
  var path: String
  var queryItems: [URLQueryItem] = []
}

extension Endpoint {
  var url: URL {
    var components = URLComponents()
    components.scheme = "https"
    components.host = "api.wayfair.io"
    components.path = "/" + path
    
    if !queryItems.isEmpty {
      components.queryItems = queryItems
    }
    
    return components.url!
  }
}

