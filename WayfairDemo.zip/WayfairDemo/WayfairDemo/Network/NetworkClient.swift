//
//  NetworkClient.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

protocol NetworkClient {
  func loadData<T: Decodable>(from endpoint: Endpoint) async throws -> T
}
