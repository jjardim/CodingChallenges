//
//  ProductItems.swift
//  WayfairDemo
//
//  Created by Jason Jardim on 5/2/23.
//

import Foundation

struct ProductItems: Codable, Identifiable {
    var id: String {
        return UUID().uuidString
    }
    let name: String
    let tagline: String
    let rating: Double
    let date: String
}

