//
//  Constants.swift
//  ZeeMeeDemo
//
//  Created by Jason Jardim on 4/4/23.
//

import Foundation


struct AppBehavior {
    static let buttonCornerRadius = 10.0
    static let searchTimeout = 1.6
}

