//
//  DrinkLookupResult.swift
//  ZeeMeeDemo
//
//  Created by Jason Jardim on 4/3/23.
//

import Foundation

struct DrinkLookupResult : Decodable {
  let drinks : [DrinksDetailsModel]?
}
