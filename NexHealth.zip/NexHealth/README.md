# iOS Code Challenge

Welcome to the NexHealth iOS code challenge! We're excited to conduct this exercise with you, and looking forward to seeing your work!

## Tasks

The goal of this exercise is to implement a list of patients, similar to what a user of our forms app might see in order to choose a patient and start a form session. You'll query patient data from our "API" (for this challenge, just a mock), display it in the app, and add basic user interactions, like selecting a patient.

Specific tasks are listed in the main files `ViewController.swift` and `APIManager.swift`, noted with a `Task:` prefix. Make sure to review each item and get a thorough understanding of the work.

## Patient Data

We've provided a [sample API response](https://gist.githubusercontent.com/dzunk/b24a525d54103d7d59c9baa21a954d01/raw/2428f4936cb63c06daf2c57ebb0a2463d8f13e24/patients.json) you can use to fetch patient data. All of the information in the mock response is fake data generated for the purpose of this challenge, but just in case we randomly generated real contact info, don't send any emails or texts to the patients in question, or share the data publicly.

## Development Process

Follow your normal development workflow when working on this challenge. Create a branch, complete the tasks, and push your changes. When you're ready to submit, open a pull request to the `master` branch.

Take all the time you need to complete the challenge. On your first commit, include a note of how long you expect the challenge to take, e.g. `Beginning the code challenge (estimating 5 hours)`.

Don't squash your commits when opening the PR - we want to see the journey, not just the destination!

The pull request template will include a few questions to give us insight into your experience with the challenge, make sure to answer them!

## Tips

* One of our company principles is "Take ownership", and you should apply that in this challenge. We've provided a basic application structure for convenience, but you should feel free to make any adjustments, additions, or other changes you'd like to anything in this repo.
