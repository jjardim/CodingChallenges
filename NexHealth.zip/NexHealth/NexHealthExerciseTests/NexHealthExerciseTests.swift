//
//  NexHealthExerciseTests.swift
//  NexHealthExerciseTests
//
//  Created by Jason Jardim on 5/8/23.
//

import XCTest
@testable import NexHealthExercise

final class NexHealthExerciseTests: XCTestCase {
    
    var sut: HomeScreenVM!
    var apiManager: MockManager!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        apiManager = MockManager()
        sut = HomeScreenVM(apiManager: apiManager)
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        apiManager = nil
        sut = nil
    }
    
    
    func test_successfully_calls_getPatient() async {
        await sut.getData()
        
        XCTAssertEqual(apiManager.callPatientCount, 1)
    }
    
    @MainActor
    func test_successfully_calls_getStyle() async {
        await sut.getStyle()
        
        XCTAssertEqual(apiManager.callGetStyleCount, 1)
    }
    
    func test_returns_correct_patient_data() async {
        let expectedResult = [Patient(id: 1, firstName: "Jason", lastName: "Jardim", name: "Unknown", email: "aa", phoneNumber: "adf", dob: "adf", gender: "adf")]

        apiManager.patientResult = expectedResult
        
        await sut.getPatients()
        
        XCTAssertEqual(sut.patients.count, 1)
        XCTAssertEqual(sut.patients, expectedResult)
    }
    
    func test_returns_correct_style_data() async {
        let expectedResult = "red"

        apiManager.styleResult = expectedResult
        
        await sut.getStyle()
        
        XCTAssertEqual(sut.colorStyle, expectedResult)
    }
}

class MockManager: APIManaging {
    var callPatientCount = 0
    var callGetStyleCount = 0
    
    var patientResult: [Patient] = []
    var styleResult: String = ""
    
    func getStyle() async -> Result<String> {
        callGetStyleCount += 1

        return .success(data: styleResult)
    }
    
    func getPatients(from endpoint: Endpoint) async throws -> Result<[Patient]> {
        callPatientCount += 1

        return .success(data: patientResult)
    }
}
