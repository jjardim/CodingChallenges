//
//  Patient.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import Foundation


struct Patient: Identifiable, Decodable, Equatable {
    let id: Int
    let firstName: String
    let lastName: String
    let name: String
    let email: String
    let phoneNumber: String
    let dob: String
    let gender: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case firstName = "first_name"
        case lastName = "last_name"
        case name
        case email
        case phoneNumber = "phone_number"
        case dob = "date_of_birth"
        case gender
    }
}
