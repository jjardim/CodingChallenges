//
//  PatientResults.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import Foundation

struct PatientResults : Decodable {
    
    let code: Bool?
    let description: String?
    let count: Int?
    var error:[String] = []

    let data : [Patient]?
}

