//
//  ClientErrors.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import Foundation

enum ClientErrors: Error {
  case dataParsingFailed
}

