//
//  APIManager.swift
//  NexHealthExercise
//

import Foundation

enum Result<T> {
    case success(data: T)
    case failure
}

protocol APIManaging {
    func getStyle() async -> Result<String>
    func getPatients(from endpoint: Endpoint) async throws -> Result<[Patient]>
    
        
}

final class APIManager: APIManaging {
    private let session: NetworkSession
    
    init(session: NetworkSession = URLSession.shared) {
        self.session = session
    }
    
    func getStyle() async -> Result<String> {
        let mainScreenStyle = ["red", "green", "blue"]
        
        // Let's simulate an API call, as if we were querying a device configuration API
        // Task: wait a second, and return random style from array above
        do {
            try await Task.sleep(nanoseconds: 1_000_000_000)
        } catch {
            print("Get style task cancelled before firing:\n", error.localizedDescription)
        }
        
        return .success(data: mainScreenStyle.randomElement()!)
    }
    
    func getPatients(from endpoint: Endpoint) async throws -> Result<[Patient]> {
        let url = endpoint.url
        let (data, response) = try await session.data(from: url)
        
        guard let httpResponse = (response as? HTTPURLResponse), (200...299).contains(httpResponse.statusCode) else {
            throw ServerError.notOK
        }
        
        do {
            let result = try JSONDecoder().decode(PatientResults.self, from: data)
            return .success(data: result.data ?? [])
        } catch {
            throw ClientErrors.dataParsingFailed
        }
    }
}
