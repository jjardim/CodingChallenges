//
//  NetworkSession.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/8/23.
//

import Foundation

protocol NetworkSession {
    func data(from url: URL) async throws -> (Data, URLResponse)
}

extension URLSession: NetworkSession { }
