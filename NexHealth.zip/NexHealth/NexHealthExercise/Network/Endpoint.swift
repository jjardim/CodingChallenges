//
//  Endpoint.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import Foundation

struct EndPointPaths {
  static let search = "dzunk/b24a525d54103d7d59c9baa21a954d01/raw/2428f4936cb63c06daf2c57ebb0a2463d8f13e24/patients.json"
}


struct Endpoint {
  var path: String
  var queryItems: [URLQueryItem] = []
}

extension Endpoint {
  var url: URL {
    var components = URLComponents()
    components.scheme = "https"
    components.host = "gist.githubusercontent.com"
    components.path = "/" + path
    
    if !queryItems.isEmpty {
      components.queryItems = queryItems
    }
    
    return components.url!
  }
}


