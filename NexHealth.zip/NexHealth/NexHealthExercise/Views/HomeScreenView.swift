//
//  HomeScreenView.swift
//  NexHealthExercise
//

//import UIKit
import SwiftUI

/**
 * Task: Fetch patients from the API, and display the results in a table or list view
 *  1. After application launch, make an API call to get the current style.
 *  2. Indicate the current style on controller.
 *  3. Fetch patients from the API and display on the screen in table or list view.
 *  4. Handle patient selection: change patient row style based on controller style.
 *
 * Additionally:
 *  1. Show loading indicator for API calls
 *  2. Add ability to reload controller (make API calls to reload style and patients)
 *  3. Application should work in both orientations
 *  4. Application should be iPad-only
 **/


struct HomeScreenView: View {
    
    @StateObject private var viewModel = HomeScreenVM()
    
    @State var selectedIds: [Int] = []
    
    let multipleSelection: Bool
    
    var body: some View {
        if viewModel.isLoaded {
            ScrollView {
                LazyVStack {
                    ForEach(viewModel.patients, id: \.id) { patient in
                        PatientCellView(patient: patient, colorStyle: UIColor.colorWith(name: viewModel.colorStyle), isSelected:  selectedIds.contains(patient.id))
                            .onTapGesture {
                                if selectedIds.contains(patient.id) {
                                    selectedIds.removeAll(where: { $0 == patient.id })
                                } else {
                                    if multipleSelection {
                                        selectedIds.append(patient.id)
                                    } else {
                                        selectedIds.removeAll()
                                        selectedIds.append(patient.id)
                                    }
                                }
                            }
                    }
                }
            }
            .refreshable {
                selectedIds.removeAll()
                await viewModel.getData()
            }
        }  else {
            ProgressView()
                .scaleEffect(3)
                .task {
                    await viewModel.getData()
                }
        }
    }
}

struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreenView(multipleSelection: true)
        HomeScreenView(multipleSelection: true)
            .preferredColorScheme(.dark)
    }
}
