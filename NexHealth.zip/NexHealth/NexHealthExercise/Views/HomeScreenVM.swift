//
//  HomeScreenVM.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import Foundation
import UIKit
import Combine

class HomeScreenVM: ObservableObject {
    private let apiManager: APIManaging
        
    @Published private(set) var colorStyle: String?
    
    @Published private(set) var patients = [Patient]()
    
    var isLoaded: Bool {
        if patients.count > 0 && (colorStyle != nil) {
            return true
        }
        
        return false
    }
    
    init(apiManager: APIManaging = APIManager()) {
        self.apiManager = apiManager
    }
    
    private var activeTasks = Set<Task<Void, Never>>()
    
    @MainActor
    func getData() async {
        // cancel previous tasks so that the API isn't hit too many times
        activeTasks.forEach{ $0.cancel() }
        activeTasks.removeAll()

        let styleTask = Task { await getStyle() }
        let patientsTask = Task { await getPatients() }
        
        activeTasks.insert(styleTask)
        activeTasks.insert(patientsTask)
        
        await styleTask.value
        await patientsTask.value
        
        activeTasks.remove(styleTask)
        activeTasks.remove(patientsTask)
    }
    
    @MainActor
    func getPatients() async {
        
        let endpoint = Endpoint(
            path: EndPointPaths.search,
            queryItems: []
        )
        
        do {
            let result = try await apiManager.getPatients(from: endpoint)
            switch result {
            case .success(data: let patients):
                self.patients = patients
            case .failure:
                print("Failed")
            }
            
        } catch {
            print(error)
        }
    }
    
    @MainActor
    func getStyle() async {
        let result = await self.apiManager.getStyle()
        
        switch result {
        case .success(data: let data):
            self.colorStyle = data
        case .failure:
            print("*** Data failure")
        }
        
    }
}
