//
//  PatientCellView.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/5/23.
//

import SwiftUI

struct PatientCellView: View {
    
    let patient: Patient
    let colorStyle: UIColor
    
    let isSelected: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            
            Image(systemName: "person.crop.circle")
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .padding(10)
                .foregroundColor(Color(colorStyle))
            
            Text("\(patient.name)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.title2)
                .fontWeight(.bold)
                .padding(EdgeInsets(top: 10, leading: 10, bottom: 0, trailing: 0))
                .foregroundColor(Color.black)
            
            Text("\(patient.email)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.body)
                .foregroundColor(Color.gray)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 4, trailing: 0))
            
            Text("phone number : \(patient.phoneNumber)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.body)
                .foregroundColor(Color.gray)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 10, trailing: 0))
            
            Text("date of birth : \(patient.dob)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.body)
                .foregroundColor(Color.gray)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 10, trailing: 0))
            
            Text("gender : \(patient.gender)")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.body)
                .foregroundColor(Color.gray)
                .padding(EdgeInsets(top: 0, leading: 10, bottom: 10, trailing: 0))
        }
        .overlay(
            RoundedRectangle(cornerRadius: 2)
                .stroke(isSelected ? Color(colorStyle) : Color.secondary, lineWidth: isSelected ? 2.0 : 0.2)
        )
        .background(Color.white)
        .compositingGroup()
        .shadow(color:Color.secondary, radius: isSelected ? 0 : 2, x: 0, y: 0)
        .padding(20)
    }
}


struct ProductCellView_Previews: PreviewProvider {

    static let patientData = Patient(id: 36310, firstName: "Anisa", lastName: "Stokes", name: "Anisa Stokes", email: "anisa_stokes@jacobson.com", phoneNumber: "12927093119", dob: "1986-07-28", gender: "Male")

    static var previews: some View {
        PatientCellView(patient: patientData, colorStyle: .green, isSelected: false)
        PatientCellView(patient: patientData, colorStyle: .red, isSelected: false)
            .preferredColorScheme(.dark)
    }
}
