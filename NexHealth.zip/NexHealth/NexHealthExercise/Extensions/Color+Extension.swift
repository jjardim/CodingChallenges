//
//  Color+Extension.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/8/23.
//

import UIKit

extension UIColor {

    static func colorWith(name: String?, defaultColor: UIColor = .gray) -> UIColor {
        
        guard name != nil else {
            return defaultColor
        }
        
        let selector = Selector("\(name!)Color")
        
        if UIColor.self.responds(to: selector) {
            let color = UIColor.self.perform(selector).takeUnretainedValue()
            return (color as? UIColor) ?? defaultColor
        } else {
            return defaultColor
        }
    }
}

