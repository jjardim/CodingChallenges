//
//  SceneDelegate.swift
//  NexHealthExercise
//

import UIKit
import SwiftUI

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    private lazy var flowController = FlowCoordinator(window: window!)
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        
        window = UIWindow(windowScene: windowScene)
        flowController.showRootView()
        window?.makeKeyAndVisible()
    }
}

final class FlowCoordinator: ObservableObject {
    private let window: UIWindow
    
    init(window: UIWindow) {
        self.window = window
    }
    
    func showRootView() {
        let swiftUIView = HomeScreenView(multipleSelection: true)
            .environmentObject(self)
        let hostingView = UIHostingController(rootView: swiftUIView)
        
        window.rootViewController = UINavigationController(rootViewController: hostingView)
    }
}



