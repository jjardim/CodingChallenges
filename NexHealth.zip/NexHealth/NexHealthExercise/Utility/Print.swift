//
//  Print.swift
//  NexHealthExercise
//
//  Created by Jason Jardim on 5/8/23.
//

import Foundation

public func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    #if DEBUG
    Swift.print(items, separator: separator, terminator: terminator)
    #endif
}
