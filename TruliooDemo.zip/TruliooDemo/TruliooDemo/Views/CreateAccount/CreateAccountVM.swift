//
//  CreateAccountVM.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import Foundation
import SwiftUI
import AuthenticationServices

class CreateAccountVM: ObservableObject {
    
    var username: String = ""
    var password: String = ""
    
    @Published var isSaving: Bool = false

    
    func save(_ password: String, service: String, account: String) {
        
        // this fakes the look of saving with a spinner in the UI
        
        self.isSaving = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
            
            self.isSaving = false
            
            let data = Data(password.utf8)

            let query = [
                kSecValueData: data,
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account
            ] as CFDictionary
                
            let saveStatus = SecItemAdd(query, nil)
         
            if saveStatus != errSecSuccess {
                print("**** Error: \(saveStatus)")
            }
            
            if saveStatus == errSecDuplicateItem {
                self.update(data, service: service, account: account)
            }
            
            
        })
    }
    
    
    func update(_ data: Data, service: String, account: String) {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account
        ] as CFDictionary
            
        let updatedData = [kSecValueData: data] as CFDictionary
        SecItemUpdate(query, updatedData)
    }
    
    
    func read(service: String, account: String) -> Data? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true
        ] as CFDictionary
            
        var result: AnyObject?
        SecItemCopyMatching(query, &result)
        return result as? Data
    }
    
    
    func delete(service: String, account: String) {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account
        ] as CFDictionary
            
        SecItemDelete(query)
    }
}


