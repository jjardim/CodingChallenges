//
//  CreateAccountView.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import SwiftUI

struct CreateAccountView: View {
        
    @StateObject private var viewModel = CreateAccountVM()
    
    @Environment(\.dismiss) var dismiss

    @State private var showError = false
    
    var body: some View {
        ZStack {
            VStack {
                Text("CREATE ACCOUNT")
                    .padding(20)
                    .font(.title2)
                
                TextField("username", text: $viewModel.username)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .multilineTextAlignment(.center)
                    .font(.title2)
                    .padding(.all)
                    .border(Color.secondary)
                    .padding(.all)
                    .accessibility(identifier: "create.username")

                
                TextField("password \(AppBehavior.passwordMinLength) characters more", text: $viewModel.password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .multilineTextAlignment(.center)
                    .font(.title2)
                    .italic()
                    .padding(.all)
                    .border(Color.secondary)
                    .padding(.all)
                    .accessibility(identifier: "create.password")

                Spacer()
                Button("Create Account", action: {
                    if viewModel.username.isEmpty || viewModel.password.isEmpty || viewModel.password.count < AppBehavior.passwordMinLength {
                        showError.toggle()
                    } else {
                        viewModel.save(viewModel.password, service: Constants.keyChainServicename, account: viewModel.username)
             
                        // fake appearance of saving and dismissing the view
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                            dismiss()
                        })
                    }
                })
                .accessibility(identifier: "create.account.button")
                .alert(isPresented: $showError) { () -> Alert in
                    Alert(title: Text("A username and password length of \(AppBehavior.passwordMinLength) is required"))
                }
                    .frame(width: 320, height: 50)
                    .font(.title3)
                    .foregroundColor(.white)
                    .background(.blue)
                    .cornerRadius(10)
                    .padding(.bottom, 30)
            }
        }
        .showProgressView(isPresented: $viewModel.isSaving, text: "Creating Account...")

    }
}

struct CreateAccountView_Previews: PreviewProvider {
    static var previews: some View {
        CreateAccountView()
        CreateAccountView()
            .preferredColorScheme(.dark)
    }
}
