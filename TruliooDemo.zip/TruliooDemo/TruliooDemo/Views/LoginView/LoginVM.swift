//
//  ContentViewModel.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import Foundation
import SwiftUI
import Combine
import AuthenticationServices

class LoginVM: ObservableObject {
    
    @AppStorage("AUTH_KEY") var authenticated = false {
        willSet {
            objectWillChange.send()
        }
    }
    
    @AppStorage("USER_KEY") var username = ""
  
    @Published var password = ""
    @Published var invalid: Bool = false
    @Published var isLoading: Bool = false
    @Published var isLoginDisabled: Bool = false
    
    var cancellables: Set<AnyCancellable> = []

    private var keychainUsername = ""
    private var keychainPassword = ""
    
    init() {
        
        print("Currently logged on: \(authenticated)")
        print("Current User: \(username)")
        print("Login Disabled: \(isLoginDisabled)")


      $password
        .debounce(for: 0.1, scheduler: RunLoop.main)
        .map { input in
            return input.count >= AppBehavior.passwordMinLength
        }
        .assign(to: \.isLoginDisabled, on: self)
        .store(in: &cancellables)
    }
    

    func clearAuthentication() {
        self.password = ""
        withAnimation {
            authenticated.toggle()
        }
    }
    
    func authenticate() {
        
        //  lets grab the info from the Keychain with the account of "username"
        //  if we get the account lets read the data
        
        guard let userAccount  = read(service: Constants.keyChainServicename, account: username) else {
            
            // username was not in the keychain so lets just go through loading process and user will get alert that u/p not matched
            
            authenticateWithUserInfo()
            return
        }
        let password = String(decoding: userAccount, as: UTF8.self)
                
        if !password.isEmpty {
            keychainPassword = password
            keychainUsername = username
            authenticateWithUserInfo()
        }
    }
    
    
    private func authenticateWithUserInfo() {
        self.isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
        self.isLoading = false

        guard self.username.lowercased() == self.keychainUsername else {
            self.invalid = true

            return
        }

        guard self.password.lowercased() == self.keychainPassword else {
            self.invalid = true
            return
        }
        self.clearAuthentication()
      })
    }

    func logOut() {
        clearAuthentication()
    }
    

    func read(service: String, account: String) -> Data? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true
        ] as CFDictionary
            
        var result: AnyObject?
        SecItemCopyMatching(query, &result)
        return result as? Data
    }
    
    
    func clearDate() {
        
        self.username = ""
        
        let secItemClasses = [kSecClassGenericPassword, kSecClassInternetPassword, kSecClassCertificate, kSecClassKey, kSecClassIdentity]
        for itemClass in secItemClasses {
            let spec: NSDictionary = [kSecClass: itemClass]
            SecItemDelete(spec)
        }
    }
}




