//
//  ContentView.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import SwiftUI

struct LoginView: View {

    @StateObject private var viewModel = LoginVM()
    @State private var showAlert = false
    @State private var showingCreateSheet = false
    
    
    var body: some View {
        if viewModel.authenticated {
            authenticatedView
        } else {
            notAuthenticatedView
        }
    }
  
  
    var authenticatedView: some View {
      ZStack {
          VStack(alignment: .center, spacing: 40) {
              Spacer()
              
              Text("Login Successful")
                  .font(.largeTitle)
                  .bold()
                  .foregroundColor(.blue)
              
              Text("Welcome back \(viewModel.username.uppercased())!")
                  .font(.title)
                  .bold()
                  .foregroundColor(.blue)
              
              Spacer()
              
              Button("Back to Login Screen", action: viewModel.logOut)
                  .frame(width: 320, height: 70)
                  .font(.title2)
                  .foregroundColor(.white)
                  .background(.blue)
                  .cornerRadius(AppBehavior.buttonCornerRadius)
                  .padding(.bottom, 30)
          }
          .padding()
      }
    }
    
    var notAuthenticatedView: some View {
      ZStack {          
          VStack(spacing: 20) {
              Text("Demo")
                  .font(.system(size: 65))
                  .bold()
                  .foregroundColor(.blue)
                  .padding(.top, 60)
                  .textCase(.uppercase)
                  .onTapGesture {
                      print("**** Clearing Keychain Data")
                      viewModel.clearDate()
                  }
                Spacer()
              VStack(alignment: .leading, spacing: 0) {
                  TextField("username", text: $viewModel.username)
                      .autocorrectionDisabled(true)
                      .font(.title2)
                      .font(.headline)
                      .padding(.all)
                      .border(Color.secondary)
                      .textInputAutocapitalization(.never)
                      .padding(.all)

                  
                  SecureField("password", text: $viewModel.password)
                      .autocorrectionDisabled(true)
                      .font(.title2)
                      .font(.headline)
                      .italic()
                      .padding(.all)

                      .border(Color.secondary)
                      .textInputAutocapitalization(.never)
                      .privacySensitive() // very important
                      .padding(.all)

                HStack {
                    Spacer()
                    
                    Button("create an account") {
                        showingCreateSheet.toggle()
                    }
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .cornerRadius(AppBehavior.buttonCornerRadius)
                    .accessibility(identifier: "login.create.account.button")
                    Spacer()
                }
                .sheet(isPresented: $showingCreateSheet) {
                    CreateAccountView()
                }
              }
              
              Spacer()
              
              Button("Login", action: viewModel.authenticate)
                  .frame(width: 320, height: 50)
                  .font(.title3)
                  .foregroundColor(.white)
                  .background(!viewModel.isLoginDisabled ? .gray : .blue)
                  .cornerRadius(AppBehavior.buttonCornerRadius)
                  .padding(.bottom, 30)
                  .disabled(!viewModel.isLoginDisabled)
          }
          .padding()
          .alert("Username or Password is incorrect", isPresented: $viewModel.invalid) {
              Button("Dismiss", action: {})
          }
      }
      .transition(.scale)
      .showProgressView(isPresented: $viewModel.isLoading, text: "Loading...")
    }
}
    

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    LoginView()
    LoginView()
      .preferredColorScheme(.dark)
  }
}


