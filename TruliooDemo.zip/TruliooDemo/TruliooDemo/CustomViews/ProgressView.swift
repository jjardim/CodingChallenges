//
//  ProgressView.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import SwiftUI

struct StandardLoadingStyle: ProgressViewStyle {
    
    func makeBody(configuration: Configuration) -> some View {
        VStack(spacing: 0) {
            configuration.label
            ProgressView()
                .progressViewStyle(.circular)
                .scaleEffect(1.75)
                .tint(.primary.opacity(0.4))
                .padding(.top)
        }
        .frame(width: 150, height: 125)
        .padding()
        .foregroundColor(.primary.opacity(0.4))
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }
}

extension View {
    
    func showProgressView(isPresented: Binding<Bool>, disableparentView: Bool = false, text: String = "") -> some View {
        
        ZStack(alignment: .center) {
            self
            if isPresented.wrappedValue {
                if disableparentView {
                    Color.black.opacity(0.2)
                        .ignoresSafeArea()
                }
                VStack(spacing: 10) {
                    Spacer()
                    ProgressView(text)
                        .progressViewStyle(.standard)
                    Spacer()
                }
            }
        }
    }
}

extension ProgressViewStyle where Self == StandardLoadingStyle {
    static var standard: StandardLoadingStyle {
        .init()
    }
}
