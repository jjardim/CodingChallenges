//
//  TruliooDemoApp.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import SwiftUI

@main
struct TruliooDemoApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
