//
//  Constants.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//

import Foundation

struct Constants {
    static let keyChainServicename = "com.DemoApp"

}

struct AppBehavior {
    static let passwordMinLength = 6
    static let buttonCornerRadius = 10.0
}
