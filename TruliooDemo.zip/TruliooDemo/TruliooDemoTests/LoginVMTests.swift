//
//  LoginVMTests.swift
//  TruliooDemoTests
//
//  Created by Jason Jardim on 3/8/23.
//

import XCTest
@testable import TruliooDemo

// LoginViewModelTests
final class LoginVMTests: XCTestCase {
    
    override func setUp() {
    }
    
    override func tearDown() {
        
    }

    
    // sut = system under test
    func test_clearAuth_shouldClearPassword() {
        // Given
        let sut = LoginVM()
        sut.password = "1234"
        
        // When
        sut.clearAuthentication()
        
        // Then
        XCTAssert(sut.password.isEmpty)
    }

}
