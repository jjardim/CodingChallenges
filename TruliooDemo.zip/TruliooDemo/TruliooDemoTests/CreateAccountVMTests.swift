//
//  CreateAccountVMTests.swift
//  TruliooDemoTests
//
//  Created by Jason Jardim on 3/8/23.
//

import XCTest
@testable import TruliooDemo

final class CreateAccountVMTests: XCTestCase {
    
    func test_accountCreated() {
        
        let sut = CreateAccountVM()

        sut.username = "jason123"
        sut.password = "123456"
        
        sut.save(sut.password, service: Constants.keyChainServicename, account: sut.username)

        XCTAssert((sut.read(service: Constants.keyChainServicename, account: sut.username) != nil))

    }
}
