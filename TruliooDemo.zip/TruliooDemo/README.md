//
//  README.swift
//  TruliooDemo
//
//  Created by Jason Jardim on 3/8/23.
//


 Summary of App

 Create Account botton on LoginView will bring you to create screen
 From there you can create a username and password
 Once you create that you will br brought to the LoginView where you enter credintials


 Previews work for all Screens
 Light and Dark themes and colors



 LoginVM uses AppStorage to store authenticated bool and username to prepopulate the textfield
 LoginVM uses Combine to make the "Login" button on LoginView enabled or Disabled based on conditions
 LoginView - you can tap on the Title "DEMO" and that will clear the keychain storage
 LoginView uses a custom progressview to "fake" a 2 second delay to login


 CreateAccoutView simply creates a useraccount and dismissis back to LoginView when complete.
 CreateAccountView simply checks to see if there is a username and password in the viewmodel to display an alert is field are not filled out

 ProgressView is a fake loading view to display status as a view modifier


 Unit Tests
 LoginVMTest - Contains a clear login test
 CreateAccountVMTests = Contains an account creation and reading test
 
                    
 UI Tests
 TruliooDemoUITests - Contains a login UI Test
                    
                    
