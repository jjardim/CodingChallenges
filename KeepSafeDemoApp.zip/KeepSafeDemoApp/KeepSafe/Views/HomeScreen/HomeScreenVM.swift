//
//  HomeScreenVM.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import Foundation

protocol HomeScreenLoadingDelegate: NSObject {
    func didFinishedLoading()
}


class HomeScreenViewModel: ObservableObject {
  
  private(set) var photos: [Photo] = []

  weak var delegate: HomeScreenLoadingDelegate?

  private var limit = 30
  private var page = 1
  
  private lazy var endpoint = "https://picsum.photos/v2/list?page=\(self.page)&limit=\(self.limit)"

  
  func fetchItem(at index: Int) -> Photo {
    if index > photos.count - 1 {
      requestAnotherPage()
      return photos[photos.count - 1]
    } else if index < 0 {
      return photos[0]
    }
        
    return photos[index]
  }
  
  func requestAnotherPage() {
    page = page + 1
    limit = limit + 20
    
    self.decodeAPI()
  }
  
  func decodeAPI(){
      guard let url = URL(string: endpoint) else{return}

      let task = URLSession.shared.dataTask(with: url){
          data, response, error in
          
          let decoder = JSONDecoder()

          if let data = data{
              do{
                  let rawPhotos = try decoder.decode([Photo].self, from: data)
                
                  DispatchQueue.main.async {
                    self.photos.append(contentsOf: rawPhotos)
                    self.delegate?.didFinishedLoading()
                  }
              }catch{
                  print(error)
              }
          }
      }
      task.resume()
  }
}


