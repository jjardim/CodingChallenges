//
//  HomeScreenCVCell.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import UIKit
import SnapKit
import Kingfisher

final class HomeScreenCVCell: UICollectionViewCell {
  
  var imgPhoto: UIImageView = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleToFill
    imageView.clipsToBounds = true
    imageView.layer.masksToBounds = true

    return imageView
  }()
  
  
  override init(frame: CGRect) {
      super.init(frame: frame)
      addSubviews()
  }

  required init?(coder aDecoder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
  }
  
  private func addSubviews() {
    addSubview(imgPhoto)
    self.layer.borderColor = UIColor.darkGray.cgColor
    self.layer.borderWidth = 1.0
  }
  
  
  private func setupConstraints() {
    imgPhoto.snp.makeConstraints { make in
      make.edges.equalToSuperview()
    }
  }
  
  override func prepareForReuse() {
    imgPhoto.kf.cancelDownloadTask()
  }
  
  func configure(with photo: Photo, index: Int) {
    self.setupConstraints()
    setImage(urlString: photo.download_url)
  }
}

extension HomeScreenCVCell {
  func setImage(urlString: String?) {
    guard let urlString = urlString else {
      return
    }

    let url = URL(string: urlString)
    let size = CGSize(width: contentView.frame.width, height: contentView.frame.height)

    let processor = DownsamplingImageProcessor(size: size)
    
    imgPhoto.kf.setImage(
      with: url,
      placeholder: UIImage(named: "placeholderLoadingCells"),
      options: [
        .processor(processor),
          .scaleFactor(UIScreen.main.scale),
          .transition(.fade(1)),
          .cacheOriginalImage
      ])
  }
}
