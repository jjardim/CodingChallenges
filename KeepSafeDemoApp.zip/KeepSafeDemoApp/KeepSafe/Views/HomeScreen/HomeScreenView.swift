//
//  HomeScreenView.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import UIKit
import Kingfisher

class HomeScreenView: UIViewController {

  private var viewModel = HomeScreenViewModel()

  
  private lazy var collectionView: UICollectionView = {
    
    let cvLayout:UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    cvLayout.sectionInset = UIEdgeInsets(top:0,left:0,bottom:0,right:0)
    cvLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width/2 - 1, height: 150)
    cvLayout.minimumInteritemSpacing = 1
    cvLayout.minimumLineSpacing = 1
    
    cvLayout.scrollDirection = .vertical

    let cv = UICollectionView(frame: .zero, collectionViewLayout: cvLayout)
      cv.dataSource = self
      cv.isScrollEnabled = true
      cv.allowsSelection = true
      cv.backgroundColor = .clear
      cv.delegate = self
      cv.register(HomeScreenCVCell.self, forCellWithReuseIdentifier: HomeScreenCVCell.reuseIdentifier)

      return cv
  }()


  override func viewDidLoad() {
    super.viewDidLoad()
    self.title = "Mini KeepSafe"
    self.viewModel.delegate = self
    self.setupLayout()
    viewModel.decodeAPI()
  }

  
  func setupLayout() {
    view.backgroundColor = .white
    view.addSubview(collectionView)
    
    collectionView.snp.makeConstraints {
        (make) -> Void in
        make.edges.equalTo(self.view.safeAreaLayoutGuide).inset(UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
    }
  }
}


// MARK: HomeScreenLoading Delegate

extension HomeScreenView: HomeScreenLoadingDelegate {
  func didFinishedLoading() {
    print("** Did Finish Loading \(viewModel.photos.count)")
    self.collectionView.reloadData()
  }
}
// MARK: UICollectionView Delegate & Datasource

extension HomeScreenView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {

    func numberOfSections(in collectionView: UICollectionView) -> Int {
      return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return self.viewModel.photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
      let fullScreenPhotoView = FullScreenPhotoView(viewModel: viewModel, indexPath: indexPath)
      
//      self.navigationController?.modalPresentationStyle = .fullScreen
//      self.navigationController?.present(fullScreenPhotoView, animated: true)
      self.navigationController?.pushViewController(fullScreenPhotoView, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      let cell: HomeScreenCVCell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeScreenCVCell.reuseIdentifier, for: indexPath) as! HomeScreenCVCell
      let info = self.viewModel.fetchItem(at: indexPath.row)
      
      cell.configure(with: info, index: indexPath.row)

      return cell
    }
  
  func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
    if indexPath.row == viewModel.photos.count - 6 {  //numberofitem count
        updateNextSet()
    }
  }

  func updateNextSet(){
    print("** On Completetion \(viewModel.photos.count)")
    self.viewModel.requestAnotherPage()
  }
}

