//
//  FullScreenPhotoView.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import Foundation
import UIKit
import SnapKit

class FullScreenPhotoView: UIViewController {
  
  private var viewModel: HomeScreenViewModel!
  private var currentIndexPath: IndexPath
  
  
  private let imgPhoto: UIImageView = {
    let imageView = UIImageView()
    imageView.image = UIImage(named: "placeholderLoadingCells")
    imageView.contentMode = .scaleAspectFill
    imageView.clipsToBounds = true
    imageView.layer.masksToBounds = true
    imageView.layer.borderWidth = 1.0
    imageView.layer.borderColor = UIColor.darkGray.cgColor
    imageView.isUserInteractionEnabled = true
    
    return imageView
  }()
  

  init(viewModel: HomeScreenViewModel, indexPath: IndexPath) {
    self.viewModel = viewModel
    self.currentIndexPath = indexPath
    super.init(nibName: nil, bundle: nil)
    
    let info = self.viewModel.fetchItem(at: currentIndexPath.row)
    self.setImage(urlString: info.download_url)
  }

  required init?(coder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    setupLayout()
    setupConstraints()
    setupSwipeGestures()
  }

  private func setupConstraints() {
    imgPhoto.snp.makeConstraints { make in
      make.edges.equalTo(self.view)
    }
  }
  
  private func setupLayout() {
    view.backgroundColor = .white
    view.addSubview(imgPhoto)
  }
}

extension FullScreenPhotoView {
  
  private func setupSwipeGestures() {
    let swipeLeftGesture = UISwipeGestureRecognizer(target: self, action: #selector(swipeLeft))
    self.imgPhoto.isUserInteractionEnabled = true
    swipeLeftGesture.direction = UISwipeGestureRecognizer.Direction.left
    self.imgPhoto.addGestureRecognizer(swipeLeftGesture)

    let swipeRightGesture = UISwipeGestureRecognizer(target: self, action: #selector(swipeRight))
    self.imgPhoto.isUserInteractionEnabled = true
    swipeRightGesture.direction = UISwipeGestureRecognizer.Direction.right
    self.imgPhoto.addGestureRecognizer(swipeRightGesture)
  }
  
  private func setImage(urlString: String?) {
    guard let urlString = urlString else {
      return
    }

    let url = URL(string: urlString)

    imgPhoto.kf.setImage(
      with: url,
      placeholder: UIImage(named: "placeholderLoadingCells"),
      options: [
          .scaleFactor(UIScreen.main.scale),
          .transition(.fade(1)),
          .loadDiskFileSynchronously,
          .cacheOriginalImage
      ])
  }
  
  @objc private func swipeLeft( _ recognizer : UISwipeGestureRecognizer){
    // TODO: Could be issue here down the road
    currentIndexPath.row = currentIndexPath.row + 1
    let info = self.viewModel.fetchItem(at: currentIndexPath.row)
    self.setImage(urlString: info.download_url)
  }
  
  @objc private func swipeRight( _ recognizer : UISwipeGestureRecognizer){
    // TODO: Could be issue here down the road
    currentIndexPath.row = currentIndexPath.row - 1
    let info = self.viewModel.fetchItem(at: currentIndexPath.row - 1)
    self.setImage(urlString: info.download_url)
  }
}
