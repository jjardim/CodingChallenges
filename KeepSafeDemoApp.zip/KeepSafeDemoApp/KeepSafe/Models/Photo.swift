//
//  Photo.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import Foundation

struct Photo: Identifiable, Codable, Hashable {
  let id: String
  var author: String
  let width: Int
  let height: Int
  let url: String
  let download_url: String
}

//  Data Format
/*
[{"id":"0","author":"Alejandro Escamilla","width":5000,"height":3333,"url":"https://unsplash.com/photos/yC-Yzb qy7PY","download_url":"https://picsum.photos/id/0/5000/3333"}
*/
