//
//  UICollectionViewCell+Extensions.swift
//  KeepSafe
//
//  Created by Jason Jardim on 2/9/23.
//

import UIKit

extension UICollectionViewCell {
    static var reuseIdentifier: String {
        return String(describing: Self.self)
    }
}
